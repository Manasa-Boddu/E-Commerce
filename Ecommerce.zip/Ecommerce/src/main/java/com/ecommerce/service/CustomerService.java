package com.ecommerce.service;

import java.util.List;

import com.ecommerce.model.Customer;

public interface CustomerService {
	boolean addCustomer(Customer customer);

	boolean updateCustomer(Customer customer);

	boolean deleteCustomer(Long customerId);

	Customer findCustomerById(Long customerId);

	List<Customer> findAllCustomers();


}
