package com.ecommerce.model;

import org.springframework.stereotype.Component;

@Component
public class Customer {
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("CUTOMER BEAN HAS BEEN INITIALISED....");
	}
	public Customer(String customerName, int customerId, String customerEmail, String customerPassword) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.customerEmail = customerEmail;
		this.customerPassword = customerPassword;
	}
	private String customerName ; 
	private int customerId;
	private String customerEmail ;
	private String customerPassword;
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

}
