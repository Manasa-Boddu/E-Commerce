package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.model.Customer;
import com.ecommerce.repository.CustomerRepository;

@Service
public class CustomerService1 implements CustomerService{
	@Autowired
	private CustomerRepository repository;

	public CustomerService1() {
		System.out.println("###### CustomerServiceReposiory created... #########");
	}

	@Override
	public boolean addCustomer(Customer customer) {
			
		// TODO Auto-generated method stub
		return repository.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		Customer c = repository.findById(customer.getCustomerId()).get();

		if (c != null) {
			return repository.save(customer) == customer;
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(Long customerId) {

		Customer customer = repository.findById(customerId).get();

		if (customer != null) {
			repository.delete(customer);
			return true;
		}
		
		return false;
		
	}

	@Override
	public Customer findCustomerById(Long customerId) {
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}



