package com.ecommerce.model;

import org.springframework.stereotype.Component;

@Component
public class Category {
	public Category() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("CATEGORY BEAN HAS BEEN INITIALIZED....");
	}
	private int categoryId ;
	private int categoryName ;
	
	
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(int categoryName) {
		this.categoryName = categoryName;
	}

}
