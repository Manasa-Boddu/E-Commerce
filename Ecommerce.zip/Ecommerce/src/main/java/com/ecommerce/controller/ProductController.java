package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;
@Controller
public class ProductController {

	@Autowired
	private ProductService productService; 	

	public ProductController() {
	System.out.println("########ProductSpringController created....######");
	}


	@RequestMapping(value="/sproduct",method= {RequestMethod.GET , RequestMethod.POST})
	public ModelAndView getAllProducts(){
		return new ModelAndView("productList", "product", productService.findAllProducts());
	}


	@RequestMapping(value="/newProduct",method= {RequestMethod.GET , RequestMethod.POST})
	public String newProduct(ModelMap map){
		
		map.addAttribute("product", new Product());
		map.addAttribute("products", productService.findAllProducts());
			
		return "addProduct";
	}


	@RequestMapping(value="/edit/{id}",method= {RequestMethod.GET , RequestMethod.POST})
	public String newProduct(@PathVariable("id") Long productId,ModelMap map){
		
		map.addAttribute("product", productService.findProduct(productId));
		map.addAttribute("products", productService.findAllProducts());
			
		return "editProduct";
	}


	@RequestMapping(value="/delete",method= {RequestMethod.GET , RequestMethod.POST})
	public String deleteProduct(@RequestParam("id") Long productId,ModelMap map){
		
		productService.deleteProduct(productId);
		
		map.addAttribute("products", productService.findAllProducts());
			
		return "productList";
	}
	
	@RequestMapping(value="/add",method= {RequestMethod.POST , RequestMethod.GET})
	public String addProduct(@ModelAttribute("product") Product product,ModelMap map){
		productService.addProduct(product);
		map.addAttribute("customers", productService.findAllProducts());
		return "productList";
	}


	@RequestMapping(value="/update",method= {RequestMethod.POST , RequestMethod.GET})
	public String updateProduct(@ModelAttribute("product") Product product,ModelMap map){
		productService.addProduct(product);
		map.addAttribute("products", productService.findAllProducts());
		return "productList";
	}

}
