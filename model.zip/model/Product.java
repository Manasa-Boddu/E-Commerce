package com.ecommerce.model;

import org.springframework.stereotype.Component;

@Component
public class Product {
	
	public Product() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("PRODUCT CLASS HAS BEEN INITIALISED.....");
	}
	public Product(String productName, int productId, int productPrice) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productPrice = productPrice;
	}
	
	private String productName ;
	private int productId ;
	private int productPrice;
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	

}
