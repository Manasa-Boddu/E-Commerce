package com.ecommerce.model;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Cart {
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("CART BEAN HAS BEEN INITILISED....");
	}

	@Autowired
	private Customer customer;
	
	@Autowired
	private List<Order> order ;
	
	private int cartId;

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

}
