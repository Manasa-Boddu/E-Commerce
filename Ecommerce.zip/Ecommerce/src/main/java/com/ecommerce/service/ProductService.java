package com.ecommerce.service;

import java.util.List;

import com.ecommerce.model.Product;

public interface ProductService {
	
	Product findProduct(Long productId);

	boolean deleteProduct(Long productId);

	boolean updateProduct(Product product);

	boolean addProduct(Product product);

	List<Product> findAllProducts();


}
