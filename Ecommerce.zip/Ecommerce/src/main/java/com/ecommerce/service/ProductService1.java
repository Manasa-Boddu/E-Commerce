package com.ecommerce.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import  com.ecommerce.service.ProductService;
import com.ecommerce.model.Product;
import com.ecommerce.repository.ProductRepository;

@Service
public class ProductService1 implements ProductService{
@Autowired
private ProductRepository repository ;

public ProductService1() {
	System.out.println("ProductService1 is created");
}
@Override
public Product findProduct(Long productId) {
	return repository.findById(productId).get();
}
@Override
public boolean deleteProduct(Long productId) {
	Product p = repository.findById(productId).get();
	if(p!=null) {
		repository.delete(p);
		return true;
	}
	return false ;
}

@Override
public boolean updateProduct(Product product) {
	Product p = repository.findById(product.getProductId()).get();
	if(p!=null) {
		 return repository.save(product) == product;
		
	}
	return false;
}
@Override
public boolean addProduct(Product product) {
	return repository.save(product) == product;
}
@Override
public List<Product> findAllProducts(){
	return repository.findAll();
}

}
