package com.ecommerce.model;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Order {
	
	public Order(Product product, int orderId, Date orderDate, String orderAddress) {
		super();
		this.product = product;
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.orderAddress = orderAddress;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Order has been initialized.....");
	}
	
	@Autowired
	private Product product ;
	private int orderId;
	private Date orderDate ;
	private String orderAddress ;
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderAddress() {
		return orderAddress;
	}
	public void setOrderAddress(String orderAddress) {
		this.orderAddress = orderAddress;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
