package com.ecommerce;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages= {"com.ecommerce.controller.CustomerController"})
@Configuration
public class CommerceConfig {
       public CommerceConfig() {
    	   System.out.println("spring Config Created");
       }
}
